import turtle
t1=turtle.Turtle()
t1.shape("turtle")
t1.forward(100)
turtle.done()
