import random
lotto=list(range(1,46))
print('lotto=',lotto)
select_num=list()
for i in range(5):
    random.shuffle(lotto)
    print('lotto=', lotto)
    select_num.append(lotto.pop())
print('selected_num:',select_num)
