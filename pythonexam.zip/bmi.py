height=float(input('키를 입력하세요: '))
weight=float(input('몸무게를 입력하세요: '))
height=height/100
bmi=weight/height**2
if bmi<20 :
    print('bmi:',bmi,'=>','저체중')
elif bmi<25:
    print('bmi:',bmi,'=>','정상체중')
elif bmi<30:
    print('bmi:',bmi,'=>','과체중')
elif bmi<40:
    print('bmi:',bmi,'=>','비만')
else:
    print('bmi:', bmi, '=>','고도비만')