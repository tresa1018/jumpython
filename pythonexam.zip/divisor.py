#약수와 약수의 갯수를 구하는 프로그램
num=int(input('약수를 구하려는 숫자입력: '))
cnt=0
print('%d의 약수 : '%num, end='')
for i in range(1,num+1):
    if num % i==0:
        print(i,end=' ')
        cnt+=1
print('(%d개)'%cnt)