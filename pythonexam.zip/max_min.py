def getMinMax(mylist, method='max'):
    minvalue=9999999999999999999
    maxvalue=-minvalue

    if method=='max':
        for value in mylist:
            if value>maxvalue:
                maxvalue=value
        return maxvalue
    elif method=='min':
        for value in mylist:
            if value<minvalue:
                minvalue=value
        return minvalue
    else:
        print('illegal method')

list_data=list()
count=int(input('몇 개의 숫자를 넣을까요?: '))
for i in range(count):
    n=int(input('숫자를 입력하세요: '))
    list_data.append(n)

i='y'
while(i!='n'):
    print(list_data)
    s=input('구하려는 값이 최소값은 min, 최대값은 max: ')
    print(getMinMax(list_data,s))
    i=input('계속 하시겠습니까?(y/n)')





