import random

lotto=[]
print('** 로또 프로그램 시작 **')
for i in range(6):
    lotto.append(random.randint(1,45))
print('** 추첨된 로또 번호 **')
lotto.sort()

print('당첨번호: ',end='')
for i in range(6):
    print(lotto[i],end=' ')

