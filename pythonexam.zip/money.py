principal=int(input('원금을 입력하세요: '))
rate=float(input('이율을 입력하세요: '))
years=int(input('기간을 입력하세요(년단위): '))
money=principal*(1.0+rate)**years #복리이자인 경우
print('원금:', principal)
print('이율:', rate)
print('기간:', years)
print('수령금액(세전):',money)