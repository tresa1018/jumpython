print('음료자판기 입니다')
money=int(input('지폐를 투입하세요: '))
print('[coke:600원, fanta:500원, coffee:1000원, juice:2000원]')
coke=600;fanta=500;coffee=1000;juice=2000
s=input('원하시는 음료를 선택하세요: ')
if s=='coke':
    mod=money-coke
if s=='fanta':
    mod=money-fanta
if s=='coffee':
    mod=money-coffee
if s=='juice':
    mod=money-juice
change=mod
s1000=mod//1000
mod%=1000
s500=mod//500
mod%=500
s100=mod//100
mod%=100
print('잔돈:%d원,1000원:%d장,500원:%d개,100원:%d개'\
      %(change,s1000,s500,s100))