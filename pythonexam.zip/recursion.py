#재귀함수 factorial
def factorial(n):
    if n<=1:
        return 1
    else:
        return n * factorial(n-1)

x=int(input('구하려는 팩토리얼의 숫자값을 넣으시오: '))
print('%d! = %d'%(x,factorial(x)))

# 재귀함수 fibonacci
def fibonacci(n):
    if n<0:
        print('잘못된 입력힙니다')
    elif n==1:
        return 0
    elif n==2:
        return 1
    else:
        return fibonacci(n-1)+ fibonacci(n-2)

i=int(input('fibonacci의 몇 번째 항을 알고 싶은가요? '))
print(fibonacci(i))