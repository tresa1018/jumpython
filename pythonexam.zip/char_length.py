#문자열을 입력받아 문자열의 길이, 글자 위치에 따른 개별글자 찾기
string=input('문자열을 입력하세요: ')
print('문자열: ',string)
print('문자열 길이',len(string))
answer='y'
while(answer!='n'):
    index=int(input('위치에 따른 문자찾기(숫자 0부터): '))
    print('%dth character:%c'%(index,string[index]))
    answer=input('계속 찾으시겠습니까?(y/n)')