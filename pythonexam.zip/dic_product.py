#편의점 재고관리 프로그램
items={'커피음료':7,'펜':3,'종이컵':2,'우유':1,'콜라':4,'라면':10}
answer=1
while(answer!=4):
    print(items)
    select=int(input('메뉴를 선택하시오\n 1)재고조회 2)입고 3)출고 4)종료 =>'))
    if select==1:
        product=input('[재고조회] 물건의 이름을 입력하시오: ')
        if product in items:
            print('재고:',items[product])
        else:
            print('입력하신 %s는 없습니다.'%product)
    if select==2:
        product, count=input('[입고] 물건의 이름과 수량을 입력하시오: ').split()
        if product in items:
            items[product]=int(items[product])+int(count)
            print('%s의 재고:%s'%(product, items[product]))
        else:
            print('입력하신 물품을 등록합니다.')
            items[product]=count
            print('%s의 재고:%s' % (product, items[product]))
    if select==3:
        product,count=input('[출고] 물건의 이름과 수량을 입력하시오: ').split()
        if product in items:
            if int(count)<items[product]:
                items[product]=int(items[product])-int(count)
                print('%s의 재고:%s'%(product,items[product]))
            else:
                print('현재 재고보다 수량이 적어 출고가 힘듭니다')
        else:
            print('입력하신 물품이 없습니다.')
    if select==4:
        print('프로그램을 종료합니다.')
        answer=4


