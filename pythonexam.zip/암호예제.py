print(ord('파'))
print(chr(54028))
