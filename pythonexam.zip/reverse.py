#글자를 입력받아 역순출력
string=input('문자열을 입력하세요: ')
print('문자열: ',string)
reverse=list()
for i in range(len(string)-1, -1, -1):
    reverse.append(string[i])
print(reverse)
print('역순 문자열: ',''.join(reverse))