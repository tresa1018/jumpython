import random
count_pass=0
count_fail=0
print('**** 구구단 게임 ****')
while True:
    s=input('시작하려면 아무키나 누르시고, 종료하려면 0을 누르세요')
    if s=='0': break
    dan=random.randint(2,9)
    num=random.randint(1,9)
    print('%d X % d = '%(dan,num),end='')
    answer=int(input())
    if answer==dan*num:
        print('PASS')
        count_pass+=1
    else:
        print('FAIL')
        count_fail+=1

print('** 구구단 게임 결과 **')
print('맞춘갯수 : %d, 틀린갯수 : %d'%(count_pass, count_fail))