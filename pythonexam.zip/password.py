pw='admin'
cnt=0
while True:
    st = input('패스워드 입력 : ')
    if pw==st:
        print('환영합니다')
        break
    else:
        print('암호가 틀립니다.')
        cnt+=1
        if cnt>=3:
            print('시도횟수초과')
            break
print('프로그램 종료')