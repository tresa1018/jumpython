X=[1,2,3,4,5]
Y=map(lambda a: a*a, X)
print(Y)
print(list(Y))
