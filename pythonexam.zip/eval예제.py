numstr=input('수식계산입력  :')
answer=eval(numstr) # 문자열로 받은 수식을 인터프리터가 변역함
print(answer)
