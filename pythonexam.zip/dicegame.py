import random
print('******** 주사위 게임 ********')
throw=input('Enter를 누르면 게임이 시작됩니다')
while throw!='0':
    com=random.randint(1,6)
    user=int(input(' 1~6 사이 주사위 숫자 num: '))
    if com>user:
        print('com의 수:%d, user의 수: %d,winner: com'%(com,user))
    elif user>com:
        print('com의 수:%d, user의 수: %d,winner: user'%(com,user))
    else:
        print('비겼습니다.')

    throw=input('재시작하려면 Enter, 아니면 0를 누르세요')