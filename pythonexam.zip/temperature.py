#섭씨온도와 화씨온도를 모두 출력
celsius=int(input('섭씨 온도를 입력하세요: '))
fahrenheit=(9/5)* celsius+32
print('섭씨 %d도는 화씨 %.1f도 입니다'%(celsius, fahrenheit))