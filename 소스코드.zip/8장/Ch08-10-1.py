#CH08-10. 키워드 인수

##################################################################
##위치 인수(positional argument)

def calc(x, y):
    return x - y

print( calc(10, 20) )
print( calc(20, 10) )
