#CH07-03. 리스트 항목에 접근하기


##################################################################
##리스트 항목을 슬라이싱
letters = ['A', 'B', 'C', 'D', 'E', 'F']
print(letters[0:3])
print(letters[ : 3])
print(letters[3 : ])
print(letters[:])

