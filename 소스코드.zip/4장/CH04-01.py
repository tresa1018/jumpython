#CH04-01 파이썬에서 사용할 수 있는 자료의 종류

x = 10
print("x =", x)

x = 3.14
print("x =", x)

x = "Hello World!"
print("x =", x)
