#천둥번개가 발생한 곳은 얼마나 떨어져있나?

sec = int(input("측정 시간(초) 입력: "))
distance = 340 * sec
print("자신의 위치에서 번개가 친 장소까지의 거리=", distance, "m")
