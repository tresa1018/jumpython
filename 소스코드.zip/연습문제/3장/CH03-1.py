x = int(input("x: "))
y = int(input("y: "))

print("두 수의 합: ", x+y)
print("두 수의 차: ", x-y)
print("두 수의 곱: ", x*y)
print("두 수의 평균: ", (x+y)/2)
print("큰 수: ", max(x, y))
print("작은 수: ", min(x, y))
