str = input("문자열을 입력하시오: ")
s = str[0:2] + str[-2:]

print(s)
