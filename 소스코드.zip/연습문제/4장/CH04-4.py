str = input("평문: ")
print("암호문: "+str[-1: :-1])
