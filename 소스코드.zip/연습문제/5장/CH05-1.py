age = 20
if age < 20:
    print('20살 미만')
else:
    print('20살 이상')
