temp = int(input("현재 온도를 입력하시오: "))

if temp >= 25:
    print("반바지를 추천합니다.")
else:
    print("긴바지를 추천합니다.")
