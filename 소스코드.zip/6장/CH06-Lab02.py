#CH06-Lab02 도돌이표

print("연주 순서")
print("A", end=" ")
print("B", end=" ")

for i in range(2):
    print("C", end=" ")
    print("D", end=" ")
