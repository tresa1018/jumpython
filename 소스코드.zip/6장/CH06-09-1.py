#CH06-09. break 와 continue

##################################################################
##break 프로그램

while True:
    light = input('신호등 색상을 입력하시오: ')
    if light == 'blue':
        break
print( '전진!!')
