#원 그리기
import turtle

t = turtle.Turtle()
t.shape("turtle")
t.circle(100)	#반지름이 100인 원을 그림
